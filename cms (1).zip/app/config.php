<?php

define("PATH" , realpath('.'));
const URL = "https://3etasimacilik.com/";
return [
     'db' => [
         'host' => 'localhost',
         'user' => 'etasimac_byk1lla',
         'pass' => 'Rootuser8112005.',
         'name' => 'etasimac_3etasimacilik',
     ]
];
