<?php
class test
{
    public function __construct()
    {
        echo "Lütfen bu mesajı görüyorsanız geri dönün";
    }
}