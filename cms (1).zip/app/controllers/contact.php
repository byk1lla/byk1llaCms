<?php

$meta = [
    'title' => "İletişim",
    'description' => setting('description'),
    'keywords' => setting('keywords')
];
require View("contact");