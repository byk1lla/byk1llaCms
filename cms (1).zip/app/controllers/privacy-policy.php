<?php

$meta = [
    "title" => "Gizlilik Politikası"
];
$text = setting("privacy-policy");
require View("privacy-policy");