<?php
$meta = [
    'title' => "Bakımdayız!",
    'description' => setting('description'),
    'keywords' => setting('keywords')
];
require PATH. "/app/views/bakim.php";