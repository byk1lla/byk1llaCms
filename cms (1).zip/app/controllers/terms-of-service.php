<?php

$meta = [
    "title" => "Kullanım Şartları"
];
$text = setting("terms");

require View("terms-of-service");