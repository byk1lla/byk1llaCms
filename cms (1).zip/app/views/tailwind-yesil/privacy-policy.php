<?php require View("static/header")?>

<div class="container mx-auto py-12 px-4 md:px-12 bg-gray-100">
    <h2 class="text-3xl font-bold text-center mb-8">Gizlilik Politikası</h2>
    <div class="text-gray-800">
        <p><?=$text?></p>

    </div>
</div>
<?php require View("static/footer")?>
