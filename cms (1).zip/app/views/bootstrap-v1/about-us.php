<?php require View("static/header")?>
    <div class="container py-5 bg-light">
        <h2 class="text-center mb-4">Hakkımızda</h2>
        <div class="text-muted">
            <p><?=$text?></p>

        </div>
    </div>


<?php require View("static/footer")?>