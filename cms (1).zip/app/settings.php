<?php 

$settings["title"]="3E Taşımacılık";
$settings["favicon"]="public/uploads/settings/66c11d0245abd_logo-org.jpg";
$settings["nav_icon"]="public/uploads/settings/66c11d0245fa7_logo.png";
$settings["description"]="3E Taşımacılık, Evden Eve nakliyat";
$settings["keywords"]="Evden Eve Taşıma, Ev Taşıma, 3E Taşımacılık, 3e taşımacılık, 3e tasimacilik, evden eve tasima, tasima, taşıma, nakliye, Nakliye";
$settings["hero_title"]="3E Taşımacılık";
$settings["hero_description"]="sizin için en iyisini yapıyoruz";
$settings["theme"]="tailwind-mavi";
$settings["categories_title"]="Kategorilerimiz";
$settings["categories_description"]="Sizler için en iyi kategorileri yaptık!";
$settings["products_title"]="Hizmetlerimiz";
$settings["product_description"]="Aşağıda Hizmetlerimizi inceleyebilirsiniz.";
$settings["bakim"]="0";
$settings["bakim_title"]="Üzgünüz...";
$settings["bakim_description"]="Şuan bakımdayız. Lütfen daha sonra ziyaret edin.";
$settings["terms"]="<h3><strong>Kullanım Koşulları (Terms of Use)</strong></h3>
<p><strong>Bu web sitesine erişerek ve kullanarak aşağıdaki koşulları kabul etmiş sayılırsınız.</strong></p>
<h4>1. <strong>Kabul</strong></h4>
<p>Wel Studios web sitesine erişerek, bu kullanım koşullarını kabul etmiş sayılırsınız.</p>
<h4>2. <strong>Kullanıcı Sorumlulukları</strong></h4>
<ul>
<li>Web sitemizi yalnızca yasal ve ahlaki amaçlarla kullanabilirsiniz.</li>
<li>Web sitemizde sunulan içeriklerin telif haklarına ve diğer mülkiyet haklarına saygı göstermeniz gerekmektedir.</li>
</ul>
<h4>3. <strong>Fikri Mülkiyet</strong></h4>
<p>Wel Studios'a ait tüm içerik, grafikler, logolar, resimler ve diğer materyaller telif hakkı ile korunmaktadır. İzinsiz kopyalama, dağıtma veya kullanma yasaktır.</p>
<h4>4. <strong>Hizmetin Kesintisi</strong></h4>
<p>Wel Studios, hizmetlerini herhangi bir zamanda bildirimde bulunmaksızın durdurma hakkını saklı tutar.</p>
<h4>5. <strong>Üçüncü Taraf Bağlantıları</strong></h4>
<p>Sitemizde üçüncü taraf web sitelerine bağlantılar bulunabilir. Wel Studios, bu sitelerin içeriklerinden sorumlu değildir.</p>
<h4>6. <strong>Sorumluluğun Sınırlandırılması</strong></h4>
<p>Wel Studios, web sitesinin kullanımı nedeniyle doğrudan veya dolaylı olarak meydana gelebilecek zararlardan sorumlu değildir.</p>
<h4>7. <strong>Değişiklikler</strong></h4>
<p>Wel Studios, bu kullanım koşullarını herhangi bir zamanda değiştirme hakkını saklı tutar. Yapılan değişiklikler web sitemizde yayınlanacaktır.</p>
<h4>8. <strong>İletişim</strong></h4>
<p>Bu kullanım koşullarıyla ilgili sorularınız varsa, lütfen bize iletişim sayfasından ulaşın.</p>";
$settings["privacy-policy"]="<h3><strong>Gizlilik Politikası (Privacy Policy)</strong></h3>
<p><strong>Wel Studios olarak, gizliliğinizi koruma konusunda kararlıyız.</strong></p>
<p>Bu Gizlilik Politikası, kişisel verilerinizi nasıl topladığımızı, kullandığımızı, paylaştığımızı ve koruduğumuzu açıklamaktadır.</p>
<h4>1. <strong>Topladığımız Bilgiler</strong></h4>
<p>Kişisel bilgileriniz, tarafımıza gönüllü olarak sağladığınız bilgilerden oluşur. Bunlar:</p>
<ul>
<li>İsim, e-posta adresi, telefon numarası</li>
<li>İletişim bilgileri</li>
<li>Ürün siparişlerine ilişkin bilgiler</li>
</ul>
<h4>2. <strong>Bilgilerin Kullanımı</strong></h4>
<p>Topladığımız bilgileri şu amaçlarla kullanırız:</p>
<ul>
<li>Siparişlerinizi işleme koymak</li>
<li>Sorularınıza yanıt vermek</li>
<li>Size hizmetlerimizi sunmak ve geliştirmek</li>
</ul>
<h4>3. <strong>Çerezler (Cookies)</strong></h4>
<p>Web sitemizde kullanıcı deneyimini iyileştirmek için çerezler kullanıyoruz. Çerezleri reddedebilir veya silebilirsiniz, ancak bu durumda web sitemizin bazı özelliklerini kullanamayabilirsiniz.</p>
<h4>4. <strong>Bilgilerin Paylaşımı</strong></h4>
<p>Kişisel bilgilerinizi üçüncü taraflarla paylaşmayız, yalnızca:</p>
<ul>
<li>Yasal gereklilikler doğrultusunda</li>
<li>Hizmetlerimizi sunmak için gerekli olduğunda (örneğin, ödeme sağlayıcıları)</li>
</ul>
<h4>5. <strong>Bilgilerin Korunması</strong></h4>
<p>Kişisel verilerinizi yetkisiz erişim, kötüye kullanım veya açıklamaya karşı korumak için gerekli teknik ve organizasyonel önlemleri alıyoruz.</p>
<h4>6. <strong>Haklarınız</strong></h4>
<p>Kişisel bilgilerinize erişme, bunları düzeltme veya silme hakkına sahipsiniz. Bu konuda bize iletişim sayfasından ulaşabilirsiniz.</p>";
$settings["about-us"]="<p><strong>Hakkımızda</strong></p>
<p>Uzun yıllara dayanan tecrübemiz ve müşteri memnuniyetine verdiğimiz önemle, evden eve taşımacılık ve nakliyat hizmetlerinde güvenilir ve profesyonel bir hizmet sunuyoruz. Her taşınma süreci, müşterilerimizin ihtiyaçlarına özel olarak planlanır ve en küçük detayına kadar özenle gerçekleştirilir.</p>
<p><strong>Neden Bizi Tercih Etmelisiniz?</strong></p>
<p>Eşyalarınızı taşırken gösterdiğimiz hassasiyet, bizi sektörde öne çıkaran en önemli özelliklerimizden biridir. Profesyonel ekibimiz, taşınma sürecinin her aşamasında yanınızda olarak, hızlı, güvenli ve sorunsuz bir taşınma deneyimi yaşamanızı sağlar.</p>
<p><strong>İletişim</strong></p>
<p>Siz de stressiz ve rahat bir taşınma süreci için bizimle iletişime geçebilirsiniz. Bize ulaşmak için telefon numaramız: <a href='tel:+90 533 458 14 49'>+90 533 458 14 49</a>. Sizin için en iyi hizmeti sunmak üzere buradayız!</p>";
