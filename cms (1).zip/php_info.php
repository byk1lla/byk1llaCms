<?php

echo phpinfo();