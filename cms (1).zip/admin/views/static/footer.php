<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <p><?=date("Y")?> &copy; byk1lla</p>
        </div>
        <div class="float-end">
            <p class=" text-center"><a href="https://github.com/byk1lla">byk1lla</a> <i class="fas fa-handshake text-primary"></i>  <a href="/admin"><?=setting('title')?></a>
                <br> <span class="text-smr">Tüm hakları Sakldır.</span></p>
        </div>
    </div>
</footer>
</div>
</div>
<script src="<?=admin_pub()?>/static/js/components/dark.js"></script>
<script src="<?=admin_pub()?>/extensions/perfect-scrollbar/perfect-scrollbar.min.js"></script>


<script src="<?=admin_pub()?>/compiled/js/app.js"></script>



<!-- Need: Apexcharts -->
<script src="<?=admin_pub()?>/extensions/apexcharts/apexcharts.min.js"></script>
<script src="<?=admin_pub()?>/static/js/pages/dashboard.js"></script>
<script src="<?=admin_pub()?>/extensions/sweetalert2/sweetalert2.min.js"></script>
<!--<script src="--><?php //=admin_pub()?><!--/static/js/pages/sweetalert2.js"></script> -->
<script src="<?=admin_pub()?>/extensions/jquery/jquery.min.js"></script>
<script src="<?=admin_pub()?>/extensions/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?=admin_pub()?>/extensions/datatables.net-bs5/js/dataTables.bootstrap5.min.js"></script>
<script src="<?=admin_pub()?>/static/js/pages/datatables.js"></script>
<script src="<?=admin_pub()?>/static/js/pages/tinymce.js"></script>

</body>

</html>