<?php

session_destroy();
ob_clean();
header("location:/admin/");